

helm install -f $(realpath ./values.yaml) -ntst1 --wait --timeout 60 validator/